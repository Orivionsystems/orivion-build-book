# ORIVION Document Vault and Legal Document Workflow

ORIVION now has the beginning of a document vault.

## Purpose

The document vault organizes the legal, policy, investor, technical, operational, and Atlas documents that are needed to build the company responsibly.

It is also the foundation for the Founder Legal Stack: NDAs, founder agreements, IP assignments, contractor agreements, advisor agreements, privacy policy, terms, responsible AI policy, data rights policy, security policy, incident response plan, investor data room index, and related documents.

## What it manages

- folders
- documents
- versions
- document review requests
- attorney-review status
- audit trail integration

## New tables

- `document_folders`
- `documents`
- `document_versions`
- `document_reviews`

## Starter document categories

- legal
- policy
- investor
- technical
- atlas
- operations

## New routes

```text
POST /documents/folders
GET /documents/folders
POST /documents/
GET /documents/
GET /documents/{document_id}
GET /documents/{document_id}/versions
POST /documents/{document_id}/versions
POST /documents/reviews
GET /documents/reviews/list
```

## Legal workflow

A document can move through the following states:

```text
draft
in_review
approved
rejected
archived
```

## Future expansion

Later phases should add file uploads, document templates, e-signature integration, attorney invite workflow, comments, redlines, version comparison, PDF export, approval workflows, retention policies, and document-level permissions.

Atlas / Black Atlas records should eventually receive document-level provenance, source status, review state, chain-of-custody notes, and evidence methodology metadata.
