# ORIVION Audit Logs and Activity History

ORIVION now has the beginning of an accountability layer.

## Purpose

Audit logs preserve institutional trust.

They help answer:

- Who created this organization?
- Who created this workspace?
- Who added this member?
- Who created this task?
- Who created this memory item?
- Which workspace was involved?
- When did it happen?

## New route

```text
GET /audit-logs/
```

Optional query parameters:

```text
organization_id
workspace_id
limit
```

## Access control

Audit logs follow the same role-based access structure:

- workspace logs require workspace viewer access
- organization logs require organization viewer access
- personal logs are limited to the current user when no scope is supplied

## Future expansion

Later, ORIVION should audit:

- logins
- failed logins
- document views
- document edits
- agent decisions
- agent delegation
- memory searches
- data exports
- permission changes
- compliance approvals

## Principle

ORIVION should not only be intelligent.

It should be accountable.
