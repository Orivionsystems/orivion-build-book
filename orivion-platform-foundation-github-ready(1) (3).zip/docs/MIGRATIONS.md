# ORIVION Database Migrations

ORIVION now uses Alembic for database migrations.

## Why migrations matter

A serious platform cannot rely on automatic table creation forever.

Migrations allow the database to evolve safely as ORIVION adds organizations, workspaces, memberships, agents, memory records, audit logs, documents, billing, and governance controls.

## Run migrations

From the repository root:

```bash
alembic upgrade head
```

## Create a new migration later

```bash
alembic revision --autogenerate -m "describe change"
```

Then review the generated file before applying it.

## Development rule

Do not manually change production database tables.

Change the models, generate a migration, review it, then run the migration.
