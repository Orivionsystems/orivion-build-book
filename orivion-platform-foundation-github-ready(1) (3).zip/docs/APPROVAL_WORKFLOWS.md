# ORIVION Approval Workflows

ORIVION now has a human approval workflow layer.

## Purpose

High-risk AI actions should require human review before execution.

Approval workflows protect users, customers, founders, confidential data, company reputation, legal compliance, and agent accountability.

## New tables

- `approval_requests`
- `approval_events`

## Approval statuses

- pending
- approved
- rejected
- cancelled
- expired

## New routes

```text
POST /approvals/
GET /approvals/
GET /approvals/{approval_request_id}
POST /approvals/{approval_request_id}/approve
POST /approvals/{approval_request_id}/reject
GET /approvals/{approval_request_id}/events
```

## Who can approve

The current starter rule is:

- editors can request approval
- admins can approve or reject
- viewers can see approval activity

## What should require approval

Examples:

- high-risk tool execution
- external API calls
- email sending
- document edits
- legal document finalization
- financial output
- data export
- sensitive workspace access

## Future expansion

Later ORIVION should support multi-step approvals, approval expiration, reviewer assignment, approval comments, reminders, escalation, templates, compliance review lanes, and signed approval records.

## Principle

ORIVION can become powerful, but permission must remain deliberate.
