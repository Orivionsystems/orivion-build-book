# ORIVION Storage Architecture

ORIVION now has a first persistent storage layer.

## Current phase

This phase uses SQLAlchemy with SQLite for local development.

SQLite is appropriate at this stage because it is:

- simple
- local
- easy to run
- good for prototyping
- not dependent on external hosting

## Current stored entities

- Users
- Tasks
- Memory items

## Why this matters

Earlier versions used in-memory Python lists. Those lists disappeared when the backend restarted.

Persistent storage allows ORIVION to preserve core records between sessions.

## Next storage upgrades

### 1. Database migrations

Add Alembic so the database can evolve safely over time.

### 2. PostgreSQL

Move from SQLite to PostgreSQL when the project is ready for hosted environments.

### 3. Semantic memory

Add a vector database for meaning-based search.

Candidates:

- pgvector
- Qdrant
- Chroma
- Milvus
- LanceDB

### 4. Object/file storage

Add S3-compatible storage for uploaded files, generated reports, contracts, PDFs, images, and research artifacts.

### 5. Audit log

Every important user action and agent decision should eventually create an audit record.

## Principle

ORIVION memory should not just store data.

It should preserve institutional intelligence.
