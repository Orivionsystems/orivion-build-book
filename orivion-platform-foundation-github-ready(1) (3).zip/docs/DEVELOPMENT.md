# ORIVION Development Guide

This guide explains how to run the prototype locally.

## Backend

From the repository root:

```bash
cd backend
python -m venv venv
source venv/bin/activate  # macOS/Linux
# Windows: venv\Scripts\activate
pip install -r requirements.txt
cd ..
uvicorn backend.main:app --reload
```

The API should be available at:

- `http://localhost:8000`
- `http://localhost:8000/health`
- `http://localhost:8000/docs`

## Frontend

From the repository root:

```bash
cd frontend
npm install
npm run start
```

The frontend should be available at:

- `http://localhost:5173`

## Environment variables

The backend currently supports:

- `ORIVION_APP_NAME`
- `ORIVION_APP_VERSION`
- `ORIVION_ENVIRONMENT`
- `ORIVION_JWT_SECRET_KEY`
- `ORIVION_JWT_ALGORITHM`
- `ORIVION_ACCESS_TOKEN_EXPIRE_MINUTES`
- `ORIVION_ALLOWED_ORIGINS`

The frontend currently supports:

- `VITE_API_BASE_URL`

## Current prototype limitations

This build uses in-memory storage for tasks, users, and memory. Data resets when the server restarts.

The next major architecture upgrade should introduce persistent storage.
