# ORIVION Workspaces and Role-Based Access Control

ORIVION is now structured for organizations and workspaces.

## Organization

An organization represents a company, institution, team, foundation, family office, project entity, nonprofit, public agency, or community.

Examples:

- EcoVerra Global
- Plenary Enterprises
- Black Atlas Institute
- Pooch Kaboose
- A city agency
- A school system
- A private development group

## Workspace

A workspace is a focused operating area inside an organization.

Examples:

- Real Estate Development
- Legal Documents
- Black Atlas Research
- DC Convention Center Strategy
- Grants
- Family Office
- AI Product Build

## Roles

ORIVION supports four starter roles.

### Owner

Full control of the organization.

### Admin

Can manage members and workspaces.

### Editor

Can create and edit tasks, memory, and project work.

### Viewer

Can view organization and workspace content.

## Why RBAC matters

Role-based access control protects ORIVION from becoming chaotic as more people and agents enter the system.

The platform must know who can see information, add information, change information, invite users, and manage sensitive workspaces.
