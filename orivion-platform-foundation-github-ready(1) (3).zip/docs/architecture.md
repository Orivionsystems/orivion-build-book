# ORIVION Architecture

ORIVION is an AI operating system and enterprise intelligence platform. It is not a chatbot, a simple SaaS shell, or a loose collection of bots.

## Platform Layers

### ORIVION Core OS

The core operating layer manages:

- users
- organizations
- workspaces
- memberships and RBAC
- tasks
- memory
- agents
- tool permissions
- approval workflows
- audit logs
- document vault records

This layer must stay clean, runnable, and testable before specialized agent behavior expands.

### Atlas / Black Atlas

Atlas / Black Atlas is a serious knowledge, evidence, archive, methodology, and ledger system. It is intended to preserve and organize records, evidence, testimony, historical harms, land loss, destroyed Black towns, generational wealth loss, institutional misconduct, and reparative claims.

Atlas content should be treated as evidence-bearing material, not casual content. Future Atlas features should include source methodology, provenance, review status, claims, timelines, family or community submissions, archival records, and reparations ledger structures.

### Founder Legal Stack

The founder legal layer organizes company-building documents such as NDAs, founder agreements, IP assignments, contractor agreements, advisor agreements, privacy policy, terms, responsible AI policy, data rights policy, security policy, incident response plan, investor data room index, and related documents.

Legal workflows must preserve attorney-review controls, document status, version history, and audit trails.

### Agent / Bot Ecosystem

Agents are specialized workers governed by the platform. They should operate through RBAC, workspace permissions, tool permissions, approval workflows, audit logs, and human review for high-risk actions.

Planned agents include:

- CEOAgent
- ResearchAgent
- LegalAgent
- AtlasResearchAgent
- RealEstateAgent
- GrantAgent
- BusinessDevelopmentAgent
- FounderDocsAgent
- InvestorAgent
- MemoryAgent
- ComplianceAgent

## Governance Principle

ORIVION should be powerful but controlled. Do not bypass RBAC, audit logs, permissions, approval workflows, or review states to make implementation easier.

## Build Priority

The first priority is the backend foundation:

- installable dependencies
- clean imports
- local database setup
- ordered Alembic migrations
- FastAPI startup
- authenticated route behavior
- test coverage around core platform contracts

Build agent behavior module by module after the governed platform foundation is stable.

## Current Technical Shape

- `backend` contains the FastAPI API, SQLAlchemy models, auth, RBAC, audit logs, agents, tools, approvals, and document vault routes.
- `alembic` contains migrations through the current local schema.
- `agents` contains starter agent classes.
- `tests` contains backend smoke and route registration tests.
- `frontend` and `apps/web` are early frontend shells and should be reconciled later.
- `docs` contains architecture, platform, and patch notes.

## Near-Term Engineering Work

- Expand tests for RBAC, tool execution, approval decisions, document reviews, and document versioning.
- Migrate Pydantic model config to Pydantic v2 `ConfigDict`.
- Add Atlas-specific data models for evidence, sources, claims, timelines, and review status.
- Add founder legal document templates and review workflow states.
- Reconcile frontend folders into one clear app path.
