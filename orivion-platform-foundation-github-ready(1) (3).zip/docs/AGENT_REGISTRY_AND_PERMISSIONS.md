# ORIVION Agent Registry and Permissions

ORIVION now has the beginning of agent governance.

## Purpose

Agents should not be unrestricted.

The platform must know:

- which agents exist
- which agents are enabled
- which workspaces they can operate in
- what actions they can perform
- whether they can read memory
- whether they can write memory
- whether they can create tasks
- whether they can execute tools

## New tables

- `agents`
- `agent_workspace_permissions`
- `agent_runs`

## New routes

```text
GET /agents/available
POST /agents/
GET /agents/
POST /agents/permissions
GET /agents/permissions
GET /agents/runs
```

## Starter and planned agents

Current built-in starter agents:

- CEOAgent
- ResearchAgent

Planned governed agents:

- LegalAgent
- AtlasResearchAgent
- RealEstateAgent
- GrantAgent
- BusinessDevelopmentAgent
- FounderDocsAgent
- InvestorAgent
- MemoryAgent
- ComplianceAgent

## Why this matters

A finance agent should not automatically access legal memory.
A research agent should not automatically execute external tools.
A public-facing assistant should not automatically see private strategy work.
An autonomous agent should not operate inside a workspace without approval.

Atlas / Black Atlas agents must treat evidence, testimony, source methodology, claims, and historical records as serious archival material. Legal and founder-document agents must preserve human and attorney-review controls.

## Future expansion

- per-agent tool permissions
- per-agent memory scopes
- agent approval workflows
- agent run review
- agent suspension
- agent versioning
- human-in-the-loop confirmations
- tool execution sandboxes
