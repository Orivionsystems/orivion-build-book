# ORIVION Phase 7 Agent Registry and Agent Permissions Patch

This patch adds controlled agent management.

## Purpose

ORIVION needs to know which agents exist, which are active, which workspaces they can operate inside, and what each agent is allowed to do.

## Adds

- `agents` database table
- `agent_workspace_permissions` database table
- `agent_runs` database table
- Alembic migration `0003_add_agent_registry_permissions.py`
- `backend/agent_registry.py`
- `backend/agent_management.py`
- updated task routing with agent permission checks
- updated main router registration
- documentation

## Suggested commit message

`Add agent registry and workspace permissions`

## Apply after Phase 6

```bash
alembic upgrade head
uvicorn backend.main:app --reload
```
