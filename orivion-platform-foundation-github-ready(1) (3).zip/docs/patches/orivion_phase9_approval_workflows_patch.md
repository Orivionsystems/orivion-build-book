# ORIVION Phase 9 Approval Workflows Patch

This patch adds human approval workflows for high-risk agent and tool actions.

## Why this matters

ORIVION is being designed as a serious AI operating system. Agents should not automatically perform sensitive actions without review.

High-risk actions may include sending email, editing documents, calling external APIs, accessing sensitive memory, exporting data, creating legal/financial outputs, triggering external workflows, or acting on behalf of a user or company.

## Adds

- `approval_requests` table
- `approval_events` table
- Alembic migration `0005_add_approval_workflows.py`
- approval service helper
- approval API routes
- model additions
- database model additions
- main router addition
- integration notes for tool execution
- documentation
- tracker update rows for Google Sheets/Gemini tracker

## Suggested commit message

`Add approval workflows for high-risk actions`

## Apply after Phase 8

```bash
alembic upgrade head
uvicorn backend.main:app --reload
```

## Design principle

ORIVION should become powerful, but not reckless.

Human approval protects the company, the user, the customer, and the integrity of the system.
