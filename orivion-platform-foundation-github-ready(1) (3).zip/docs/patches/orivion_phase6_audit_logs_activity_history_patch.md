# ORIVION Phase 6 Audit Logs and Activity History Patch

This patch adds ORIVION's accountability layer.

## Purpose

ORIVION must be able to track what happened, who did it, when it happened, and where it happened.

This patch adds:

- audit log database table
- audit log migration
- audit helper function
- audit log API route
- activity history documentation
- updated database models
- updated API models
- updated main API router registration

## Suggested commit message

`Add audit logs and activity history`

## Apply after Phase 5

After applying this patch, run:

```bash
alembic upgrade head
```

Then start the backend:

```bash
uvicorn backend.main:app --reload
```

## Current audit log support

This phase establishes the table and route. The next phase can wire every create/update/delete action into this audit system.
