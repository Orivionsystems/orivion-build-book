# ORIVION Phase 5 Migrations, Workspaces, and RBAC Patch

This patch adds the next three major foundation layers:

1. Database migrations with Alembic
2. Organization and workspace structure
3. Role-based access control

## Why this matters

ORIVION should not operate as a single-user toy application.

A serious platform needs database migrations so the schema can evolve safely, organizations so companies/institutions/teams can have separate spaces, workspaces so each organization can separate projects and memory, and role-based permissions so people can safely collaborate.

## What this patch includes

- Alembic migration setup
- Initial migration file
- Organization database model
- Workspace database model
- Membership database model
- Role enum: owner, admin, editor, viewer
- Organization/workspace API router
- RBAC helper functions
- Task and memory workspace protection
- Documentation for migrations, workspaces, and RBAC

## Suggested commit message

`Add migrations, workspaces, and role-based access control`

## After applying

Install requirements:

```bash
pip install -r backend/requirements.txt
```

Run migration:

```bash
alembic upgrade head
```

Start backend:

```bash
uvicorn backend.main:app --reload
```
