# ORIVION Phase 4 Persistent Storage Patch

This patch moves ORIVION from temporary in-memory storage to a database-backed prototype.

## Why this matters

Until now, tasks, users, and memory items lived only in Python lists.
That is fine for proving the structure, but it is not enough for a serious platform.

This patch introduces:

- SQLAlchemy database foundation
- SQLite development database
- persistent user storage
- persistent task storage
- persistent memory storage
- cleaner database dependency injection
- safer backend structure for future PostgreSQL migration
- `.env.example` for local configuration

## New / updated backend files

- `backend/database.py`
- `backend/db_models.py`
- `backend/config.py`
- `backend/auth.py`
- `backend/tasks.py`
- `backend/memory.py`
- `backend/main.py`
- `backend/requirements.txt`

## New docs

- `.env.example`
- `docs/STORAGE_ARCHITECTURE.md`

## Suggested commit message

`Add persistent database storage layer`

## Current storage model

This phase uses SQLite for local development.

Later production migration should move to:

- PostgreSQL for users, tasks, organizations, audit logs, and structured records
- pgvector, Qdrant, Chroma, Milvus, or LanceDB for semantic memory
- S3-compatible object storage for files
- Redis for queues, sessions, caching, and real-time orchestration

## Important production warning

This is not yet production-grade.

The database layer is now structured, but ORIVION still needs:

- migrations with Alembic
- real organization/workspace model
- role-based access controls
- encrypted secrets
- background task queue
- audit logs
- production deployment hardening
