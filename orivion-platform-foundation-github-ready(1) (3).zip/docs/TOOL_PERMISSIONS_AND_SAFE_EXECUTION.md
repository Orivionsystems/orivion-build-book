# ORIVION Tool Permissions and Safe Execution Controls

ORIVION now has the foundation for controlled tool usage.

## Purpose

Agents should not execute tools automatically without governance.

This layer tracks:

- registered tools
- tool risk levels
- whether human approval is required
- which agent can use which tool
- which workspace the permission applies to
- execution history

## New tables

- `tools`
- `agent_tool_permissions`
- `tool_executions`

## Tool risk levels

- low
- medium
- high
- critical

## Starter tool registry

- memory_search
- task_create
- research_summarize
- external_api_call

## New routes

```text
GET /tools/available
POST /tools/
GET /tools/
POST /tools/permissions
GET /tools/permissions
POST /tools/execute
GET /tools/executions
```

## Principle

Agents may be intelligent, but permission must remain intentional.
