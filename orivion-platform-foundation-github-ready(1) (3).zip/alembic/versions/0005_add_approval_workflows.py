"""Add approval workflows

Revision ID: 0005_add_approval_workflows
Revises: 0004_add_tool_permissions_execution
Create Date: 2026-06-19
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "0005_add_approval_workflows"
down_revision: Union[str, None] = "0004_add_tool_permissions_execution"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.create_table(
        "approval_requests",
        sa.Column("id", sa.Integer(), primary_key=True, index=True),
        sa.Column("organization_id", sa.Integer(), sa.ForeignKey("organizations.id"), nullable=True, index=True),
        sa.Column("workspace_id", sa.Integer(), sa.ForeignKey("workspaces.id"), nullable=False, index=True),
        sa.Column("requester_user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True, index=True),
        sa.Column("reviewer_user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True, index=True),
        sa.Column("agent_id", sa.Integer(), sa.ForeignKey("agents.id"), nullable=True, index=True),
        sa.Column("tool_id", sa.Integer(), sa.ForeignKey("tools.id"), nullable=True, index=True),
        sa.Column("task_id", sa.Integer(), sa.ForeignKey("tasks.id"), nullable=True, index=True),
        sa.Column("tool_execution_id", sa.Integer(), sa.ForeignKey("tool_executions.id"), nullable=True, index=True),
        sa.Column("request_type", sa.String(length=100), nullable=False, index=True),
        sa.Column("risk_level", sa.String(length=50), nullable=False, index=True),
        sa.Column("status", sa.String(length=100), nullable=False, index=True),
        sa.Column("requested_action_summary", sa.Text(), nullable=False),
        sa.Column("decision_notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("decided_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "approval_events",
        sa.Column("id", sa.Integer(), primary_key=True, index=True),
        sa.Column("approval_request_id", sa.Integer(), sa.ForeignKey("approval_requests.id"), nullable=False, index=True),
        sa.Column("actor_user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True, index=True),
        sa.Column("event_type", sa.String(length=100), nullable=False, index=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

def downgrade() -> None:
    op.drop_table("approval_events")
    op.drop_table("approval_requests")
