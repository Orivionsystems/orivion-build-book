import type { PropsWithChildren } from "react";

type StatusCardProps = PropsWithChildren<{
  title: string;
  status: string;
}>;

export function StatusCard({ title, status, children }: StatusCardProps) {
  return (
    <article className="status-card">
      <div className="status-card__header">
        <h2>{title}</h2>
        <span>{status}</span>
      </div>
      <p>{children}</p>
    </article>
  );
}

