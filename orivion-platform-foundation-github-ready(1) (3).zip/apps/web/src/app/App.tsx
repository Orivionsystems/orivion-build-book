import { Activity, Compass, LayoutDashboard, Sparkles } from "lucide-react";
import { platformAreas } from "@orivion/shared";
import { StatusCard } from "../components/StatusCard";

export function App() {
  return (
    <main className="shell">
      <aside className="sidebar" aria-label="Primary navigation">
        <div className="brand">
          <Sparkles aria-hidden="true" size={22} />
          <span>Orivion</span>
        </div>
        <nav>
          <a className="nav-item active" href="#overview">
            <LayoutDashboard aria-hidden="true" size={18} />
            Overview
          </a>
          <a className="nav-item" href="#map">
            <Compass aria-hidden="true" size={18} />
            Platform Map
          </a>
          <a className="nav-item" href="#signal">
            <Activity aria-hidden="true" size={18} />
            Signals
          </a>
        </nav>
      </aside>

      <section className="workspace" id="overview">
        <header className="page-header">
          <div>
            <p className="eyebrow">Platform starter</p>
            <h1>Build the first Orivion workflow.</h1>
          </div>
          <button type="button">Define milestone</button>
        </header>

        <section className="summary-band" aria-label="Platform summary">
          <div>
            <span className="metric">0</span>
            <span className="label">active workflows</span>
          </div>
          <div>
            <span className="metric">{platformAreas.length}</span>
            <span className="label">starter areas</span>
          </div>
          <div>
            <span className="metric">1</span>
            <span className="label">web app shell</span>
          </div>
        </section>

        <section className="area-grid" aria-label="Starter areas">
          {platformAreas.map((area) => (
            <StatusCard key={area.id} title={area.name} status={area.status}>
              {area.description}
            </StatusCard>
          ))}
        </section>
      </section>
    </main>
  );
}

