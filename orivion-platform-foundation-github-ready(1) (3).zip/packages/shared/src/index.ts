export type PlatformArea = {
  id: string;
  name: string;
  description: string;
  status: "planned" | "draft" | "active";
};

export const platformAreas: PlatformArea[] = [
  {
    id: "identity",
    name: "Identity",
    description: "Account, organization, permission, and profile foundations.",
    status: "planned"
  },
  {
    id: "workspace",
    name: "Workspace",
    description: "The main operating surface where users return to do focused work.",
    status: "draft"
  },
  {
    id: "signals",
    name: "Signals",
    description: "Events, updates, and system state that help users know what changed.",
    status: "planned"
  }
];

