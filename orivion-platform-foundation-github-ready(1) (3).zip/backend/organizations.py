from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .auth import get_current_user
from .database import get_db
from .db_models import MembershipORM, OrganizationORM, UserORM, WorkspaceORM
from .models import (
    Membership,
    MembershipCreate,
    Organization,
    OrganizationCreate,
    Role,
    UserInDB,
    Workspace,
    WorkspaceCreate,
)
from .rbac import require_org_role


router = APIRouter(prefix="/organizations", tags=["organizations"])


@router.post("/", response_model=Organization, status_code=status.HTTP_201_CREATED)
def create_organization(
    org_in: OrganizationCreate,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> Organization:
    if current_user.id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Current user is missing database identity",
        )

    organization = OrganizationORM(
        name=org_in.name,
        description=org_in.description,
        owner_user_id=current_user.id,
    )
    db.add(organization)
    db.commit()
    db.refresh(organization)

    membership = MembershipORM(
        organization_id=organization.id,
        user_id=current_user.id,
        role=Role.owner.value,
    )
    db.add(membership)
    db.commit()

    return organization


@router.get("/", response_model=List[Organization])
def list_my_organizations(
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> List[Organization]:
    if current_user.id is None:
        return []

    return (
        db.query(OrganizationORM)
        .join(MembershipORM, MembershipORM.organization_id == OrganizationORM.id)
        .filter(MembershipORM.user_id == current_user.id)
        .order_by(OrganizationORM.id.asc())
        .all()
    )


@router.post(
    "/{organization_id}/workspaces",
    response_model=Workspace,
    status_code=status.HTTP_201_CREATED,
)
def create_workspace(
    organization_id: int,
    workspace_in: WorkspaceCreate,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> Workspace:
    require_org_role(db, current_user, organization_id, Role.editor)

    workspace = WorkspaceORM(
        organization_id=organization_id,
        name=workspace_in.name,
        description=workspace_in.description,
    )
    db.add(workspace)
    db.commit()
    db.refresh(workspace)

    return workspace


@router.get("/{organization_id}/workspaces", response_model=List[Workspace])
def list_workspaces(
    organization_id: int,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> List[Workspace]:
    require_org_role(db, current_user, organization_id, Role.viewer)

    return (
        db.query(WorkspaceORM)
        .filter(WorkspaceORM.organization_id == organization_id)
        .order_by(WorkspaceORM.id.asc())
        .all()
    )


@router.post(
    "/{organization_id}/memberships",
    response_model=Membership,
    status_code=status.HTTP_201_CREATED,
)
def add_membership(
    organization_id: int,
    membership_in: MembershipCreate,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> Membership:
    require_org_role(db, current_user, organization_id, Role.admin)

    user = db.query(UserORM).filter(UserORM.id == membership_in.user_id).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    existing = (
        db.query(MembershipORM)
        .filter(
            MembershipORM.organization_id == organization_id,
            MembershipORM.user_id == membership_in.user_id,
        )
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User is already a member of this organization",
        )

    membership = MembershipORM(
        organization_id=organization_id,
        user_id=membership_in.user_id,
        role=membership_in.role.value,
    )
    db.add(membership)
    db.commit()
    db.refresh(membership)

    return membership


@router.get("/{organization_id}/memberships", response_model=List[Membership])
def list_memberships(
    organization_id: int,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> List[Membership]:
    require_org_role(db, current_user, organization_id, Role.admin)

    return (
        db.query(MembershipORM)
        .filter(MembershipORM.organization_id == organization_id)
        .order_by(MembershipORM.id.asc())
        .all()
    )
