from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .agent_registry import get_available_agent_keys, is_builtin_agent
from .audit import record_audit_log
from .auth import get_current_user
from .database import get_db
from .db_models import AgentORM, AgentRunORM, AgentWorkspacePermissionORM
from .models import Agent, AgentCreate, AgentRun, AgentWorkspacePermission, AgentWorkspacePermissionCreate, Role, UserInDB
from .rbac import require_workspace_role

router = APIRouter(prefix="/agents", tags=["agents"])

@router.get("/available", response_model=List[str])
def list_available_builtin_agents() -> List[str]:
    return get_available_agent_keys()

@router.post("/", response_model=Agent, status_code=status.HTTP_201_CREATED)
def register_agent(agent_in: AgentCreate, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> Agent:
    if not is_builtin_agent(agent_in.key):
        raise HTTPException(status_code=400, detail="Agent key is not available in the built-in agent registry")
    existing = db.query(AgentORM).filter(AgentORM.key == agent_in.key).first()
    if existing:
        raise HTTPException(status_code=400, detail="Agent is already registered")
    agent = AgentORM(
        key=agent_in.key,
        name=agent_in.name,
        description=agent_in.description,
        agent_type=agent_in.agent_type,
        enabled=agent_in.enabled,
    )
    db.add(agent)
    db.commit()
    db.refresh(agent)
    record_audit_log(db, user_id=current_user.id, organization_id=None, workspace_id=None, action="created", entity_type="agent", entity_id=agent.id, description=f"Registered agent: {agent.key}")
    return agent

@router.get("/", response_model=List[Agent])
def list_registered_agents(db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[Agent]:
    return db.query(AgentORM).order_by(AgentORM.id.asc()).all()

@router.post("/permissions", response_model=AgentWorkspacePermission, status_code=status.HTTP_201_CREATED)
def grant_agent_workspace_permission(permission_in: AgentWorkspacePermissionCreate, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> AgentWorkspacePermission:
    require_workspace_role(db, current_user, permission_in.workspace_id, Role.admin)
    agent = db.query(AgentORM).filter(AgentORM.id == permission_in.agent_id).first()
    if agent is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    existing = db.query(AgentWorkspacePermissionORM).filter(AgentWorkspacePermissionORM.agent_id == permission_in.agent_id, AgentWorkspacePermissionORM.workspace_id == permission_in.workspace_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Agent already has permissions for this workspace")
    permission = AgentWorkspacePermissionORM(
        agent_id=permission_in.agent_id,
        workspace_id=permission_in.workspace_id,
        can_read_memory=permission_in.can_read_memory,
        can_write_memory=permission_in.can_write_memory,
        can_create_tasks=permission_in.can_create_tasks,
        can_execute_tools=permission_in.can_execute_tools,
    )
    db.add(permission)
    db.commit()
    db.refresh(permission)
    record_audit_log(db, user_id=current_user.id, organization_id=None, workspace_id=permission.workspace_id, action="created", entity_type="agent_workspace_permission", entity_id=permission.id, description=f"Granted workspace permissions to agent {agent.key}")
    return permission

@router.get("/permissions", response_model=List[AgentWorkspacePermission])
def list_agent_permissions(workspace_id: int, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[AgentWorkspacePermission]:
    require_workspace_role(db, current_user, workspace_id, Role.viewer)
    return db.query(AgentWorkspacePermissionORM).filter(AgentWorkspacePermissionORM.workspace_id == workspace_id).order_by(AgentWorkspacePermissionORM.id.asc()).all()

@router.get("/runs", response_model=List[AgentRun])
def list_agent_runs(workspace_id: int, limit: int = 100, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[AgentRun]:
    require_workspace_role(db, current_user, workspace_id, Role.viewer)
    return db.query(AgentRunORM).filter(AgentRunORM.workspace_id == workspace_id).order_by(AgentRunORM.id.desc()).limit(limit).all()
