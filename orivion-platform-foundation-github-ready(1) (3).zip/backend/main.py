from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .agent_management import router as agent_management_router
from .approval_workflows import router as approval_workflows_router
from .audit_logs import router as audit_logs_router
from .auth import router as auth_router
from .config import settings
from .document_vault import router as document_vault_router
from .memory import router as memory_router
from .organizations import router as organizations_router
from .tasks import router as tasks_router
from .tool_management import router as tool_management_router


app = FastAPI(
    title=settings.app_name,
    description="Backend API for the ORIVION enterprise intelligence platform.",
    version=settings.app_version,
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(auth_router)
app.include_router(organizations_router)
app.include_router(tasks_router)
app.include_router(memory_router)
app.include_router(audit_logs_router)
app.include_router(agent_management_router)
app.include_router(tool_management_router)
app.include_router(approval_workflows_router)
app.include_router(document_vault_router)


@app.get("/")
async def read_root():
    return {"message": "Welcome to ORIVION API"}


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "environment": settings.environment,
        "version": settings.app_version,
    }
