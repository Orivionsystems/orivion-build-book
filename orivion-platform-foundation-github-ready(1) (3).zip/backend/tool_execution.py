from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from .db_models import AgentORM, AgentToolPermissionORM, ToolExecutionORM, ToolORM


def check_tool_permission(db: Session, *, agent_id: int, tool_id: int, workspace_id: int):
    agent = db.query(AgentORM).filter(AgentORM.id == agent_id, AgentORM.enabled == True).first()
    if agent is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Enabled agent not found")

    tool = db.query(ToolORM).filter(ToolORM.id == tool_id, ToolORM.enabled == True).first()
    if tool is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Enabled tool not found")

    permission = (
        db.query(AgentToolPermissionORM)
        .filter(
            AgentToolPermissionORM.agent_id == agent_id,
            AgentToolPermissionORM.tool_id == tool_id,
            AgentToolPermissionORM.workspace_id == workspace_id,
            AgentToolPermissionORM.can_execute == True,
        )
        .first()
    )
    if permission is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Agent does not have permission to execute this tool in this workspace")

    return agent, tool, permission


def requires_approval(tool, permission) -> bool:
    if permission.requires_approval_override is not None:
        return permission.requires_approval_override
    return tool.requires_human_approval


def create_tool_execution_record(db: Session, *, agent_id: int, tool_id: int, workspace_id: int, task_id: int | None, status_value: str, approval_status: str, input_summary: str | None, output_summary: str | None = None, error_message: str | None = None):
    execution = ToolExecutionORM(
        agent_id=agent_id,
        tool_id=tool_id,
        workspace_id=workspace_id,
        task_id=task_id,
        status=status_value,
        approval_status=approval_status,
        input_summary=input_summary,
        output_summary=output_summary,
        error_message=error_message,
    )
    db.add(execution)
    db.commit()
    db.refresh(execution)
    return execution
