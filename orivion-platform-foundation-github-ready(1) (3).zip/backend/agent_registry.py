from typing import Type

from agents.base_agent import BaseAgent
from agents.ceo_agent import CEOAgent
from agents.research_agent import ResearchAgent

AVAILABLE_AGENT_CLASSES: dict[str, Type[BaseAgent]] = {
    "CEOAgent": CEOAgent,
    "ResearchAgent": ResearchAgent,
}

def get_available_agent_keys() -> list[str]:
    return sorted(AVAILABLE_AGENT_CLASSES.keys())

def build_agent(agent_key: str) -> BaseAgent:
    agent_class = AVAILABLE_AGENT_CLASSES[agent_key]
    return agent_class(name=agent_key)

def is_builtin_agent(agent_key: str) -> bool:
    return agent_key in AVAILABLE_AGENT_CLASSES
