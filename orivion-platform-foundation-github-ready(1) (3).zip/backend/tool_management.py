from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .audit import record_audit_log
from .auth import get_current_user
from .database import get_db
from .db_models import AgentToolPermissionORM, ToolExecutionORM, ToolORM
from .models import (
    AgentToolPermission,
    AgentToolPermissionCreate,
    Role,
    Tool,
    ToolCreate,
    ToolExecution,
    ToolExecutionRequest,
    UserInDB,
)
from .rbac import require_workspace_role
from .tool_execution import check_tool_permission, create_tool_execution_record, requires_approval
from .tool_registry import get_available_tool_keys, get_tool_definition, is_builtin_tool

router = APIRouter(prefix="/tools", tags=["tools"])

@router.get("/available", response_model=List[str])
def list_available_tools() -> List[str]:
    return get_available_tool_keys()

@router.post("/", response_model=Tool, status_code=status.HTTP_201_CREATED)
def register_tool(tool_in: ToolCreate, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> Tool:
    if not is_builtin_tool(tool_in.key):
        raise HTTPException(status_code=400, detail="Tool key is not available in the built-in registry")

    existing = db.query(ToolORM).filter(ToolORM.key == tool_in.key).first()
    if existing:
        raise HTTPException(status_code=400, detail="Tool is already registered")

    definition = get_tool_definition(tool_in.key)
    tool = ToolORM(
        key=tool_in.key,
        name=tool_in.name or definition["name"],
        description=tool_in.description or definition["description"],
        tool_type=tool_in.tool_type or definition["tool_type"],
        risk_level=tool_in.risk_level.value,
        requires_human_approval=tool_in.requires_human_approval,
        enabled=tool_in.enabled,
    )
    db.add(tool)
    db.commit()
    db.refresh(tool)

    record_audit_log(db, user_id=current_user.id, organization_id=None, workspace_id=None, action="created", entity_type="tool", entity_id=tool.id, description=f"Registered tool: {tool.key}")
    return tool

@router.get("/", response_model=List[Tool])
def list_tools(db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[Tool]:
    return db.query(ToolORM).order_by(ToolORM.id.asc()).all()

@router.post("/permissions", response_model=AgentToolPermission, status_code=status.HTTP_201_CREATED)
def grant_tool_permission(permission_in: AgentToolPermissionCreate, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> AgentToolPermission:
    require_workspace_role(db, current_user, permission_in.workspace_id, Role.admin)

    existing = db.query(AgentToolPermissionORM).filter(
        AgentToolPermissionORM.agent_id == permission_in.agent_id,
        AgentToolPermissionORM.tool_id == permission_in.tool_id,
        AgentToolPermissionORM.workspace_id == permission_in.workspace_id,
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Agent already has a permission record for this tool and workspace")

    permission = AgentToolPermissionORM(
        agent_id=permission_in.agent_id,
        tool_id=permission_in.tool_id,
        workspace_id=permission_in.workspace_id,
        can_execute=permission_in.can_execute,
        requires_approval_override=permission_in.requires_approval_override,
    )
    db.add(permission)
    db.commit()
    db.refresh(permission)

    record_audit_log(db, user_id=current_user.id, organization_id=None, workspace_id=permission.workspace_id, action="created", entity_type="agent_tool_permission", entity_id=permission.id, description="Granted tool permission to agent")
    return permission

@router.get("/permissions", response_model=List[AgentToolPermission])
def list_tool_permissions(workspace_id: int, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[AgentToolPermission]:
    require_workspace_role(db, current_user, workspace_id, Role.viewer)
    return db.query(AgentToolPermissionORM).filter(AgentToolPermissionORM.workspace_id == workspace_id).order_by(AgentToolPermissionORM.id.asc()).all()

@router.post("/execute", response_model=ToolExecution, status_code=status.HTTP_201_CREATED)
def request_tool_execution(execution_in: ToolExecutionRequest, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> ToolExecution:
    require_workspace_role(db, current_user, execution_in.workspace_id, Role.editor)
    agent, tool, permission = check_tool_permission(db, agent_id=execution_in.agent_id, tool_id=execution_in.tool_id, workspace_id=execution_in.workspace_id)

    if requires_approval(tool, permission):
        status_value = "pending_approval"
        approval_status = "required"
        output_summary = None
    else:
        status_value = "completed"
        approval_status = "not_required"
        output_summary = f"Executed placeholder tool: {tool.key}"

    execution = create_tool_execution_record(
        db,
        agent_id=agent.id,
        tool_id=tool.id,
        workspace_id=execution_in.workspace_id,
        task_id=execution_in.task_id,
        status_value=status_value,
        approval_status=approval_status,
        input_summary=execution_in.input_summary,
        output_summary=output_summary,
    )

    record_audit_log(db, user_id=current_user.id, organization_id=None, workspace_id=execution.workspace_id, action="created", entity_type="tool_execution", entity_id=execution.id, description=f"Tool execution requested for {tool.key}")
    return execution

@router.get("/executions", response_model=List[ToolExecution])
def list_tool_executions(workspace_id: int, limit: int = 100, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[ToolExecution]:
    require_workspace_role(db, current_user, workspace_id, Role.viewer)
    return db.query(ToolExecutionORM).filter(ToolExecutionORM.workspace_id == workspace_id).order_by(ToolExecutionORM.id.desc()).limit(limit).all()
