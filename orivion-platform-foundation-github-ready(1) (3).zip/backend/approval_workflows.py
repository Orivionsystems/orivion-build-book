from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .approval_service import create_approval_request, decide_approval_request
from .audit import record_audit_log
from .auth import get_current_user
from .database import get_db
from .db_models import ApprovalEventORM, ApprovalRequestORM
from .models import ApprovalDecision, ApprovalEvent, ApprovalRequest, ApprovalRequestCreate, Role, UserInDB
from .rbac import require_workspace_role


router = APIRouter(prefix="/approvals", tags=["approvals"])


@router.post("/", response_model=ApprovalRequest)
def request_approval(
    approval_in: ApprovalRequestCreate,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> ApprovalRequest:
    workspace = require_workspace_role(db, current_user, approval_in.workspace_id, Role.editor)

    approval = create_approval_request(
        db,
        organization_id=approval_in.organization_id or workspace.organization_id,
        workspace_id=approval_in.workspace_id,
        requester_user_id=current_user.id,
        agent_id=approval_in.agent_id,
        tool_id=approval_in.tool_id,
        task_id=approval_in.task_id,
        tool_execution_id=approval_in.tool_execution_id,
        request_type=approval_in.request_type.value,
        risk_level=approval_in.risk_level,
        requested_action_summary=approval_in.requested_action_summary,
    )

    record_audit_log(
        db,
        user_id=current_user.id,
        organization_id=approval.organization_id,
        workspace_id=approval.workspace_id,
        action="created",
        entity_type="approval_request",
        entity_id=approval.id,
        description=f"Approval requested: {approval.request_type}",
    )

    return approval


@router.get("/", response_model=List[ApprovalRequest])
def list_approvals(
    workspace_id: int,
    status_filter: str | None = None,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> List[ApprovalRequest]:
    require_workspace_role(db, current_user, workspace_id, Role.viewer)

    query = db.query(ApprovalRequestORM).filter(ApprovalRequestORM.workspace_id == workspace_id)

    if status_filter is not None:
        query = query.filter(ApprovalRequestORM.status == status_filter)

    return query.order_by(ApprovalRequestORM.id.desc()).limit(limit).all()


@router.get("/{approval_request_id}", response_model=ApprovalRequest)
def get_approval(
    approval_request_id: int,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> ApprovalRequest:
    approval = db.query(ApprovalRequestORM).filter(ApprovalRequestORM.id == approval_request_id).first()
    if approval is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Approval request not found")

    require_workspace_role(db, current_user, approval.workspace_id, Role.viewer)
    return approval


@router.post("/{approval_request_id}/approve", response_model=ApprovalRequest)
def approve_request(
    approval_request_id: int,
    decision: ApprovalDecision,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> ApprovalRequest:
    existing = db.query(ApprovalRequestORM).filter(ApprovalRequestORM.id == approval_request_id).first()
    if existing is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Approval request not found")

    require_workspace_role(db, current_user, existing.workspace_id, Role.admin)

    approval = decide_approval_request(
        db,
        approval_request_id=approval_request_id,
        reviewer_user_id=current_user.id,
        decision="approved",
        notes=decision.notes,
    )

    record_audit_log(
        db,
        user_id=current_user.id,
        organization_id=approval.organization_id,
        workspace_id=approval.workspace_id,
        action="approved",
        entity_type="approval_request",
        entity_id=approval.id,
        description="Approval request approved",
    )

    return approval


@router.post("/{approval_request_id}/reject", response_model=ApprovalRequest)
def reject_request(
    approval_request_id: int,
    decision: ApprovalDecision,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> ApprovalRequest:
    existing = db.query(ApprovalRequestORM).filter(ApprovalRequestORM.id == approval_request_id).first()
    if existing is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Approval request not found")

    require_workspace_role(db, current_user, existing.workspace_id, Role.admin)

    approval = decide_approval_request(
        db,
        approval_request_id=approval_request_id,
        reviewer_user_id=current_user.id,
        decision="rejected",
        notes=decision.notes,
    )

    record_audit_log(
        db,
        user_id=current_user.id,
        organization_id=approval.organization_id,
        workspace_id=approval.workspace_id,
        action="rejected",
        entity_type="approval_request",
        entity_id=approval.id,
        description="Approval request rejected",
    )

    return approval


@router.get("/{approval_request_id}/events", response_model=List[ApprovalEvent])
def list_approval_events(
    approval_request_id: int,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> List[ApprovalEvent]:
    approval = db.query(ApprovalRequestORM).filter(ApprovalRequestORM.id == approval_request_id).first()
    if approval is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Approval request not found")

    require_workspace_role(db, current_user, approval.workspace_id, Role.viewer)

    return (
        db.query(ApprovalEventORM)
        .filter(ApprovalEventORM.approval_request_id == approval_request_id)
        .order_by(ApprovalEventORM.id.asc())
        .all()
    )
