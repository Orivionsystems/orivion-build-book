from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .audit import record_audit_log
from .auth import get_current_user
from .database import get_db
from .db_models import DocumentFolderORM, DocumentORM, DocumentReviewORM, DocumentVersionORM
from .document_workflow_service import create_document_review, create_document_with_initial_version, create_new_document_version
from .models import Document, DocumentCreate, DocumentFolder, DocumentFolderCreate, DocumentReview, DocumentReviewCreate, DocumentVersion, DocumentVersionCreate, Role, UserInDB
from .rbac import require_workspace_role

router = APIRouter(prefix="/documents", tags=["documents"])

@router.post("/folders", response_model=DocumentFolder, status_code=status.HTTP_201_CREATED)
def create_folder(folder_in: DocumentFolderCreate, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> DocumentFolder:
    workspace = require_workspace_role(db, current_user, folder_in.workspace_id, Role.editor)
    folder = DocumentFolderORM(
        organization_id=folder_in.organization_id or workspace.organization_id,
        workspace_id=folder_in.workspace_id,
        name=folder_in.name,
        description=folder_in.description,
        created_by_user_id=current_user.id,
    )
    db.add(folder)
    db.commit()
    db.refresh(folder)
    record_audit_log(db, user_id=current_user.id, organization_id=folder.organization_id, workspace_id=folder.workspace_id, action="created", entity_type="document_folder", entity_id=folder.id, description=f"Created document folder: {folder.name}")
    return folder

@router.get("/folders", response_model=List[DocumentFolder])
def list_folders(workspace_id: int, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[DocumentFolder]:
    require_workspace_role(db, current_user, workspace_id, Role.viewer)
    return db.query(DocumentFolderORM).filter(DocumentFolderORM.workspace_id == workspace_id).order_by(DocumentFolderORM.id.asc()).all()

@router.post("/", response_model=Document, status_code=status.HTTP_201_CREATED)
def create_document(document_in: DocumentCreate, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> Document:
    workspace = require_workspace_role(db, current_user, document_in.workspace_id, Role.editor)
    document = create_document_with_initial_version(
        db,
        organization_id=document_in.organization_id or workspace.organization_id,
        workspace_id=document_in.workspace_id,
        folder_id=document_in.folder_id,
        created_by_user_id=current_user.id,
        title=document_in.title,
        document_type=document_in.document_type,
        category=document_in.category.value,
        content=document_in.content,
        requires_attorney_review=document_in.requires_attorney_review,
    )
    record_audit_log(db, user_id=current_user.id, organization_id=document.organization_id, workspace_id=document.workspace_id, action="created", entity_type="document", entity_id=document.id, description=f"Created document: {document.title}")
    return document

@router.get("/", response_model=List[Document])
def list_documents(workspace_id: int, category: str | None = None, status_filter: str | None = None, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[Document]:
    require_workspace_role(db, current_user, workspace_id, Role.viewer)
    query = db.query(DocumentORM).filter(DocumentORM.workspace_id == workspace_id)
    if category is not None:
        query = query.filter(DocumentORM.category == category)
    if status_filter is not None:
        query = query.filter(DocumentORM.status == status_filter)
    return query.order_by(DocumentORM.id.desc()).all()

@router.get("/reviews/list", response_model=List[DocumentReview])
def list_document_reviews(workspace_id: int, status_filter: str | None = None, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[DocumentReview]:
    require_workspace_role(db, current_user, workspace_id, Role.viewer)
    query = db.query(DocumentReviewORM).join(DocumentORM, DocumentORM.id == DocumentReviewORM.document_id).filter(DocumentORM.workspace_id == workspace_id)
    if status_filter is not None:
        query = query.filter(DocumentReviewORM.status == status_filter)
    return query.order_by(DocumentReviewORM.id.desc()).all()

@router.get("/{document_id}", response_model=Document)
def get_document(document_id: int, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> Document:
    document = db.query(DocumentORM).filter(DocumentORM.id == document_id).first()
    if document is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    require_workspace_role(db, current_user, document.workspace_id, Role.viewer)
    return document

@router.get("/{document_id}/versions", response_model=List[DocumentVersion])
def list_document_versions(document_id: int, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> List[DocumentVersion]:
    document = db.query(DocumentORM).filter(DocumentORM.id == document_id).first()
    if document is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    require_workspace_role(db, current_user, document.workspace_id, Role.viewer)
    return db.query(DocumentVersionORM).filter(DocumentVersionORM.document_id == document_id).order_by(DocumentVersionORM.version_number.desc()).all()

@router.post("/{document_id}/versions", response_model=DocumentVersion, status_code=status.HTTP_201_CREATED)
def add_document_version(document_id: int, version_in: DocumentVersionCreate, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> DocumentVersion:
    document = db.query(DocumentORM).filter(DocumentORM.id == document_id).first()
    if document is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    require_workspace_role(db, current_user, document.workspace_id, Role.editor)
    version = create_new_document_version(db, document_id=document_id, created_by_user_id=current_user.id, content=version_in.content, change_summary=version_in.change_summary)
    record_audit_log(db, user_id=current_user.id, organization_id=document.organization_id, workspace_id=document.workspace_id, action="created", entity_type="document_version", entity_id=version.id, description=f"Created version {version.version_number} for document {document.title}")
    return version

@router.post("/reviews", response_model=DocumentReview, status_code=status.HTTP_201_CREATED)
def request_document_review(review_in: DocumentReviewCreate, db: Session = Depends(get_db), current_user: UserInDB = Depends(get_current_user)) -> DocumentReview:
    document = db.query(DocumentORM).filter(DocumentORM.id == review_in.document_id).first()
    if document is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    require_workspace_role(db, current_user, document.workspace_id, Role.editor)
    review = create_document_review(db, document_id=review_in.document_id, document_version_id=review_in.document_version_id, requested_by_user_id=current_user.id, review_type=review_in.review_type, notes=review_in.notes)
    record_audit_log(db, user_id=current_user.id, organization_id=document.organization_id, workspace_id=document.workspace_id, action="created", entity_type="document_review", entity_id=review.id, description=f"Requested document review for {document.title}")
    return review
