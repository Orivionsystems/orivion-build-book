AVAILABLE_TOOLS = {
    "memory_search": {
        "name": "Memory Search",
        "description": "Searches ORIVION memory inside an approved workspace.",
        "tool_type": "internal",
        "risk_level": "low",
        "requires_human_approval": False,
    },
    "task_create": {
        "name": "Task Create",
        "description": "Creates tasks inside an approved workspace.",
        "tool_type": "internal",
        "risk_level": "medium",
        "requires_human_approval": False,
    },
    "research_summarize": {
        "name": "Research Summarize",
        "description": "Summarizes research text or memory into a structured brief.",
        "tool_type": "internal",
        "risk_level": "low",
        "requires_human_approval": False,
    },
    "external_api_call": {
        "name": "External API Call",
        "description": "Placeholder for future external API calls.",
        "tool_type": "external",
        "risk_level": "high",
        "requires_human_approval": True,
    },
}


def get_available_tool_keys() -> list[str]:
    return sorted(AVAILABLE_TOOLS.keys())


def is_builtin_tool(tool_key: str) -> bool:
    return tool_key in AVAILABLE_TOOLS


def get_tool_definition(tool_key: str) -> dict:
    return AVAILABLE_TOOLS[tool_key]
