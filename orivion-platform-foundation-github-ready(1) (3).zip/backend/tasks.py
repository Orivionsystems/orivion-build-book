from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .auth import get_current_user
from .database import get_db
from .db_models import TaskORM
from .models import Role, Task, TaskCreate, UserInDB
from .rbac import require_workspace_role
from agents.ceo_agent import CEOAgent
from agents.research_agent import ResearchAgent


router = APIRouter(prefix="/tasks", tags=["tasks"])

ceo_agent = CEOAgent(name="CEOAgent")
research_agent = ResearchAgent(name="ResearchAgent")


@router.post("/", response_model=Task, status_code=status.HTTP_201_CREATED)
def create_task(
    task_in: TaskCreate,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> Task:
    if task_in.workspace_id is not None:
        require_workspace_role(db, current_user, task_in.workspace_id, Role.editor)

    status_value = "created"

    if task_in.assigned_agent in (None, "CEOAgent"):
        ceo_agent.process_task(task_in.description)
        status_value = "processed_by_ceo_agent"
    elif task_in.assigned_agent == "ResearchAgent":
        research_agent.process_task(task_in.description)
        status_value = "processed_by_research_agent"
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported agent: {task_in.assigned_agent}",
        )

    task = TaskORM(
        workspace_id=task_in.workspace_id,
        description=task_in.description,
        assigned_agent=task_in.assigned_agent,
        status=status_value,
    )
    db.add(task)
    db.commit()
    db.refresh(task)

    return task


@router.get("/", response_model=List[Task])
def list_tasks(
    workspace_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> List[Task]:
    query = db.query(TaskORM)

    if workspace_id is not None:
        require_workspace_role(db, current_user, workspace_id, Role.viewer)
        query = query.filter(TaskORM.workspace_id == workspace_id)

    return query.order_by(TaskORM.id.asc()).all()


@router.get("/{task_id}", response_model=Task)
def get_task(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> Task:
    task = db.query(TaskORM).filter(TaskORM.id == task_id).first()
    if task is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found",
        )

    if task.workspace_id is not None:
        require_workspace_role(db, current_user, task.workspace_id, Role.viewer)

    return task
