import os
from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class Settings:
    """Application settings loaded from environment variables."""

    app_name: str = os.getenv("ORIVION_APP_NAME", "ORIVION API")
    app_version: str = os.getenv("ORIVION_APP_VERSION", "0.1.0")
    environment: str = os.getenv("ORIVION_ENVIRONMENT", "development")
    jwt_secret_key: str = os.getenv("ORIVION_JWT_SECRET_KEY", "dev-only-change-me")
    jwt_algorithm: str = os.getenv("ORIVION_JWT_ALGORITHM", "HS256")
    access_token_expire_minutes: int = int(
        os.getenv("ORIVION_ACCESS_TOKEN_EXPIRE_MINUTES", "30")
    )
    database_url: str = os.getenv("ORIVION_DATABASE_URL", "sqlite:///./orivion.db")
    allowed_origins_raw: str = os.getenv(
        "ORIVION_ALLOWED_ORIGINS",
        "http://localhost:5173,http://localhost:3000",
    )

    @property
    def allowed_origins(self) -> List[str]:
        return [
            origin.strip()
            for origin in self.allowed_origins_raw.split(",")
            if origin.strip()
        ]


settings = Settings()
