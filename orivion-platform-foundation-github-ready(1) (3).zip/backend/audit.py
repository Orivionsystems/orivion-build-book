from typing import Optional

from sqlalchemy.orm import Session

from .db_models import AuditLogORM


def record_audit_log(
    db: Session,
    *,
    user_id: Optional[int],
    organization_id: Optional[int],
    workspace_id: Optional[int],
    action: str,
    entity_type: str,
    entity_id: Optional[int],
    description: Optional[str] = None,
) -> AuditLogORM:
    """Create and persist an audit log record."""

    log = AuditLogORM(
        user_id=user_id,
        organization_id=organization_id,
        workspace_id=workspace_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        description=description,
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return log
