# Integration note for backend/tool_management.py

# In Phase 8, tools that require approval create a tool execution record
# with status="pending_approval".
#
# After applying Phase 9, update the pending approval branch inside
# request_tool_execution() so it also creates an approval request through
# create_approval_request().
#
# Import:
# from .approval_service import create_approval_request
#
# Then after creating a pending tool execution record, call:
#
# create_approval_request(
#     db,
#     organization_id=None,
#     workspace_id=execution.workspace_id,
#     requester_user_id=current_user.id,
#     agent_id=agent.id,
#     tool_id=tool.id,
#     task_id=execution.task_id,
#     tool_execution_id=execution.id,
#     request_type="tool_execution",
#     risk_level=tool.risk_level,
#     requested_action_summary=f"Approval required to execute tool: {tool.key}",
# )
#
# This keeps the tool execution record and approval workflow connected.
