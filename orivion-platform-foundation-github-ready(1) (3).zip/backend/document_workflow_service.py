from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from .db_models import DocumentORM, DocumentReviewORM, DocumentVersionORM


def create_document_with_initial_version(
    db: Session,
    *,
    organization_id: int | None,
    workspace_id: int,
    folder_id: int | None,
    created_by_user_id: int | None,
    title: str,
    document_type: str,
    category: str,
    content: str,
    requires_attorney_review: bool,
) -> DocumentORM:
    document = DocumentORM(
        organization_id=organization_id,
        workspace_id=workspace_id,
        folder_id=folder_id,
        created_by_user_id=created_by_user_id,
        title=title,
        document_type=document_type,
        category=category,
        status="draft",
        current_version_number=1,
        requires_attorney_review=requires_attorney_review,
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    version = DocumentVersionORM(
        document_id=document.id,
        version_number=1,
        created_by_user_id=created_by_user_id,
        content=content,
        change_summary="Initial version",
    )
    db.add(version)
    db.commit()

    return document


def create_new_document_version(
    db: Session,
    *,
    document_id: int,
    created_by_user_id: int | None,
    content: str,
    change_summary: str | None,
) -> DocumentVersionORM:
    document = db.query(DocumentORM).filter(DocumentORM.id == document_id).first()
    if document is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")

    next_version = document.current_version_number + 1

    version = DocumentVersionORM(
        document_id=document.id,
        version_number=next_version,
        created_by_user_id=created_by_user_id,
        content=content,
        change_summary=change_summary,
    )

    document.current_version_number = next_version
    document.status = "draft"
    document.updated_at = datetime.now(timezone.utc)

    db.add(version)
    db.add(document)
    db.commit()
    db.refresh(version)
    return version


def create_document_review(
    db: Session,
    *,
    document_id: int,
    document_version_id: int | None,
    requested_by_user_id: int | None,
    review_type: str,
    notes: str | None,
) -> DocumentReviewORM:
    document = db.query(DocumentORM).filter(DocumentORM.id == document_id).first()
    if document is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")

    review = DocumentReviewORM(
        document_id=document_id,
        document_version_id=document_version_id,
        requested_by_user_id=requested_by_user_id,
        review_type=review_type,
        status="requested",
        notes=notes,
    )

    document.status = "in_review"
    document.updated_at = datetime.now(timezone.utc)

    db.add(review)
    db.add(document)
    db.commit()
    db.refresh(review)
    return review
