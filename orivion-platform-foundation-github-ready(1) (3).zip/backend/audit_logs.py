from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .auth import get_current_user
from .database import get_db
from .db_models import AuditLogORM
from .models import AuditLog, Role, UserInDB
from .rbac import require_org_role, require_workspace_role


router = APIRouter(prefix="/audit-logs", tags=["audit-logs"])


@router.get("/", response_model=List[AuditLog])
def list_audit_logs(
    organization_id: int | None = None,
    workspace_id: int | None = None,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> List[AuditLog]:
    """List audit logs visible to the current user."""

    query = db.query(AuditLogORM)

    if workspace_id is not None:
        require_workspace_role(db, current_user, workspace_id, Role.viewer)
        query = query.filter(AuditLogORM.workspace_id == workspace_id)
    elif organization_id is not None:
        require_org_role(db, current_user, organization_id, Role.viewer)
        query = query.filter(AuditLogORM.organization_id == organization_id)
    else:
        if current_user.id is None:
            return []
        query = query.filter(AuditLogORM.user_id == current_user.id)

    return query.order_by(AuditLogORM.id.desc()).limit(limit).all()
