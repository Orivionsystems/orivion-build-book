from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field


ORM_MODEL_CONFIG = ConfigDict(from_attributes=True)


class Role(str, Enum):
    owner = "owner"
    admin = "admin"
    editor = "editor"
    viewer = "viewer"


class User(BaseModel):
    username: str
    full_name: Optional[str] = None
    email: Optional[EmailStr] = None
    disabled: bool = False


class UserCreate(User):
    password: str = Field(min_length=8)


class UserInDB(User):
    id: Optional[int] = None
    hashed_password: str


class Token(BaseModel):
    access_token: str
    token_type: str


class Organization(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    name: str
    description: Optional[str] = None
    owner_user_id: int


class OrganizationCreate(BaseModel):
    name: str
    description: Optional[str] = None


class Workspace(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    organization_id: int
    name: str
    description: Optional[str] = None


class WorkspaceCreate(BaseModel):
    name: str
    description: Optional[str] = None


class Membership(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    organization_id: int
    user_id: int
    role: Role


class MembershipCreate(BaseModel):
    user_id: int
    role: Role = Role.viewer


class Task(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    workspace_id: Optional[int] = None
    description: str
    assigned_agent: Optional[str] = None
    status: str = "created"


class TaskCreate(BaseModel):
    description: str
    assigned_agent: Optional[str] = None
    workspace_id: Optional[int] = None


class MemoryItem(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    workspace_id: Optional[int] = None
    content: str


class MemoryCreate(BaseModel):
    content: str
    workspace_id: Optional[int] = None


class AuditLog(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    user_id: Optional[int] = None
    organization_id: Optional[int] = None
    workspace_id: Optional[int] = None
    action: str
    entity_type: str
    entity_id: Optional[int] = None
    description: Optional[str] = None
    created_at: datetime


class Agent(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    key: str
    name: str
    description: Optional[str] = None
    agent_type: str
    enabled: bool = True


class AgentCreate(BaseModel):
    key: str
    name: str
    description: Optional[str] = None
    agent_type: str = "internal"
    enabled: bool = True


class AgentWorkspacePermission(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    agent_id: int
    workspace_id: int
    can_read_memory: bool = True
    can_write_memory: bool = False
    can_create_tasks: bool = True
    can_execute_tools: bool = False


class AgentWorkspacePermissionCreate(BaseModel):
    agent_id: int
    workspace_id: int
    can_read_memory: bool = True
    can_write_memory: bool = False
    can_create_tasks: bool = True
    can_execute_tools: bool = False


class AgentRun(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    agent_id: int
    workspace_id: Optional[int] = None
    task_id: Optional[int] = None
    status: str
    input_summary: Optional[str] = None
    output_summary: Optional[str] = None
    created_at: datetime


class ToolRiskLevel(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class Tool(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    key: str
    name: str
    description: Optional[str] = None
    tool_type: str
    risk_level: ToolRiskLevel = ToolRiskLevel.low
    requires_human_approval: bool = False
    enabled: bool = True


class ToolCreate(BaseModel):
    key: str
    name: str
    description: Optional[str] = None
    tool_type: str = "internal"
    risk_level: ToolRiskLevel = ToolRiskLevel.low
    requires_human_approval: bool = False
    enabled: bool = True


class AgentToolPermission(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    agent_id: int
    tool_id: int
    workspace_id: int
    can_execute: bool = False
    requires_approval_override: Optional[bool] = None


class AgentToolPermissionCreate(BaseModel):
    agent_id: int
    tool_id: int
    workspace_id: int
    can_execute: bool = False
    requires_approval_override: Optional[bool] = None


class ToolExecutionRequest(BaseModel):
    agent_id: int
    tool_id: int
    workspace_id: int
    task_id: Optional[int] = None
    input_summary: Optional[str] = None


class ToolExecution(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    agent_id: int
    tool_id: int
    workspace_id: int
    task_id: Optional[int] = None
    status: str
    approval_status: str
    input_summary: Optional[str] = None
    output_summary: Optional[str] = None
    error_message: Optional[str] = None
    created_at: datetime


class ApprovalStatus(str, Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"
    cancelled = "cancelled"
    expired = "expired"


class ApprovalRequestType(str, Enum):
    tool_execution = "tool_execution"
    agent_action = "agent_action"
    data_export = "data_export"
    document_action = "document_action"
    external_api_call = "external_api_call"


class ApprovalRequestCreate(BaseModel):
    workspace_id: int
    organization_id: Optional[int] = None
    agent_id: Optional[int] = None
    tool_id: Optional[int] = None
    task_id: Optional[int] = None
    tool_execution_id: Optional[int] = None
    request_type: ApprovalRequestType = ApprovalRequestType.tool_execution
    risk_level: str = "high"
    requested_action_summary: str


class ApprovalDecision(BaseModel):
    notes: Optional[str] = None


class ApprovalRequest(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    organization_id: Optional[int] = None
    workspace_id: int
    requester_user_id: Optional[int] = None
    reviewer_user_id: Optional[int] = None
    agent_id: Optional[int] = None
    tool_id: Optional[int] = None
    task_id: Optional[int] = None
    tool_execution_id: Optional[int] = None
    request_type: str
    risk_level: str
    status: str
    requested_action_summary: str
    decision_notes: Optional[str] = None
    created_at: datetime
    decided_at: Optional[datetime] = None


class ApprovalEvent(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    approval_request_id: int
    actor_user_id: Optional[int] = None
    event_type: str
    notes: Optional[str] = None
    created_at: datetime


class DocumentCategory(str, Enum):
    legal = "legal"
    policy = "policy"
    investor = "investor"
    technical = "technical"
    atlas = "atlas"
    operations = "operations"


class DocumentStatus(str, Enum):
    draft = "draft"
    in_review = "in_review"
    approved = "approved"
    rejected = "rejected"
    archived = "archived"


class DocumentReviewStatus(str, Enum):
    requested = "requested"
    approved = "approved"
    rejected = "rejected"
    changes_requested = "changes_requested"


class DocumentFolderCreate(BaseModel):
    workspace_id: int
    organization_id: Optional[int] = None
    name: str
    description: Optional[str] = None


class DocumentFolder(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    organization_id: Optional[int] = None
    workspace_id: int
    name: str
    description: Optional[str] = None
    created_by_user_id: Optional[int] = None
    created_at: datetime


class DocumentCreate(BaseModel):
    workspace_id: int
    organization_id: Optional[int] = None
    folder_id: Optional[int] = None
    title: str
    document_type: str
    category: DocumentCategory = DocumentCategory.legal
    content: str
    requires_attorney_review: bool = False


class Document(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    organization_id: Optional[int] = None
    workspace_id: int
    folder_id: Optional[int] = None
    created_by_user_id: Optional[int] = None
    title: str
    document_type: str
    category: str
    status: str
    current_version_number: int
    requires_attorney_review: bool
    created_at: datetime
    updated_at: datetime


class DocumentVersionCreate(BaseModel):
    content: str
    change_summary: Optional[str] = None


class DocumentVersion(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    document_id: int
    version_number: int
    created_by_user_id: Optional[int] = None
    content: str
    change_summary: Optional[str] = None
    created_at: datetime


class DocumentReviewCreate(BaseModel):
    document_id: int
    document_version_id: Optional[int] = None
    review_type: str = "attorney_review"
    notes: Optional[str] = None


class DocumentReviewDecision(BaseModel):
    status: DocumentReviewStatus
    notes: Optional[str] = None


class DocumentReview(BaseModel):
    model_config = ORM_MODEL_CONFIG

    id: int
    document_id: int
    document_version_id: Optional[int] = None
    requested_by_user_id: Optional[int] = None
    reviewer_user_id: Optional[int] = None
    review_type: str
    status: str
    notes: Optional[str] = None
    created_at: datetime
    decided_at: Optional[datetime] = None
