from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .auth import get_current_user
from .database import get_db
from .db_models import MemoryItemORM
from .models import MemoryCreate, MemoryItem, Role, UserInDB
from .rbac import require_workspace_role


router = APIRouter(prefix="/memory", tags=["memory"])


@router.post("/", response_model=MemoryItem, status_code=status.HTTP_201_CREATED)
def create_memory(
    item_in: MemoryCreate,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> MemoryItem:
    if item_in.workspace_id is not None:
        require_workspace_role(db, current_user, item_in.workspace_id, Role.editor)

    memory_item = MemoryItemORM(
        workspace_id=item_in.workspace_id,
        content=item_in.content,
    )
    db.add(memory_item)
    db.commit()
    db.refresh(memory_item)
    return memory_item


@router.get("/", response_model=List[MemoryItem])
def list_memory(
    workspace_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> List[MemoryItem]:
    query = db.query(MemoryItemORM)

    if workspace_id is not None:
        require_workspace_role(db, current_user, workspace_id, Role.viewer)
        query = query.filter(MemoryItemORM.workspace_id == workspace_id)

    return query.order_by(MemoryItemORM.id.asc()).all()


@router.get("/search/", response_model=List[MemoryItem])
def search_memory(
    query: str,
    workspace_id: int | None = None,
    top_k: int = 10,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> List[MemoryItem]:
    memory_query = db.query(MemoryItemORM).filter(
        MemoryItemORM.content.ilike(f"%{query}%")
    )

    if workspace_id is not None:
        require_workspace_role(db, current_user, workspace_id, Role.viewer)
        memory_query = memory_query.filter(MemoryItemORM.workspace_id == workspace_id)

    return memory_query.order_by(MemoryItemORM.id.asc()).limit(top_k).all()


@router.get("/{memory_id}", response_model=MemoryItem)
def get_memory(
    memory_id: int,
    db: Session = Depends(get_db),
    current_user: UserInDB = Depends(get_current_user),
) -> MemoryItem:
    item = db.query(MemoryItemORM).filter(MemoryItemORM.id == memory_id).first()
    if item is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Memory item not found",
        )

    if item.workspace_id is not None:
        require_workspace_role(db, current_user, item.workspace_id, Role.viewer)

    return item
