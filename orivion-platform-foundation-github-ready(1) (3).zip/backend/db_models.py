from datetime import datetime, timezone

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint

from .database import Base


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class UserORM(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(150), unique=True, index=True, nullable=False)
    full_name = Column(String(255), nullable=True)
    email = Column(String(255), unique=True, index=True, nullable=True)
    hashed_password = Column(String(255), nullable=False)
    disabled = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class OrganizationORM(Base):
    __tablename__ = "organizations"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), index=True, nullable=False)
    description = Column(Text, nullable=True)
    owner_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class WorkspaceORM(Base):
    __tablename__ = "workspaces"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), index=True, nullable=False)
    name = Column(String(255), index=True, nullable=False)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class MembershipORM(Base):
    __tablename__ = "memberships"
    __table_args__ = (
        UniqueConstraint("organization_id", "user_id", name="uq_membership_org_user"),
    )

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=False)
    role = Column(String(50), nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class TaskORM(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=True)
    description = Column(Text, nullable=False)
    assigned_agent = Column(String(150), nullable=True)
    status = Column(String(150), default="created", nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class MemoryItemORM(Base):
    __tablename__ = "memory_items"

    id = Column(Integer, primary_key=True, index=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=True)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class AuditLogORM(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), index=True, nullable=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=True)
    action = Column(String(100), index=True, nullable=False)
    entity_type = Column(String(100), index=True, nullable=False)
    entity_id = Column(Integer, index=True, nullable=True)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class AgentORM(Base):
    __tablename__ = "agents"

    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(150), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    agent_type = Column(String(100), nullable=False)
    enabled = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class AgentWorkspacePermissionORM(Base):
    __tablename__ = "agent_workspace_permissions"
    __table_args__ = (
        UniqueConstraint("agent_id", "workspace_id", name="uq_agent_workspace_permission"),
    )

    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(Integer, ForeignKey("agents.id"), index=True, nullable=False)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=False)
    can_read_memory = Column(Boolean, default=True, nullable=False)
    can_write_memory = Column(Boolean, default=False, nullable=False)
    can_create_tasks = Column(Boolean, default=True, nullable=False)
    can_execute_tools = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class AgentRunORM(Base):
    __tablename__ = "agent_runs"

    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(Integer, ForeignKey("agents.id"), index=True, nullable=False)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), index=True, nullable=True)
    status = Column(String(100), nullable=False)
    input_summary = Column(Text, nullable=True)
    output_summary = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class ToolORM(Base):
    __tablename__ = "tools"

    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(150), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    tool_type = Column(String(100), nullable=False)
    risk_level = Column(String(50), nullable=False)
    requires_human_approval = Column(Boolean, default=False, nullable=False)
    enabled = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class AgentToolPermissionORM(Base):
    __tablename__ = "agent_tool_permissions"
    __table_args__ = (
        UniqueConstraint(
            "agent_id",
            "tool_id",
            "workspace_id",
            name="uq_agent_tool_workspace_permission",
        ),
    )

    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(Integer, ForeignKey("agents.id"), index=True, nullable=False)
    tool_id = Column(Integer, ForeignKey("tools.id"), index=True, nullable=False)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=False)
    can_execute = Column(Boolean, default=False, nullable=False)
    requires_approval_override = Column(Boolean, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class ToolExecutionORM(Base):
    __tablename__ = "tool_executions"

    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(Integer, ForeignKey("agents.id"), index=True, nullable=False)
    tool_id = Column(Integer, ForeignKey("tools.id"), index=True, nullable=False)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=False)
    task_id = Column(Integer, ForeignKey("tasks.id"), index=True, nullable=True)
    status = Column(String(100), nullable=False)
    approval_status = Column(String(100), nullable=False)
    input_summary = Column(Text, nullable=True)
    output_summary = Column(Text, nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class ApprovalRequestORM(Base):
    __tablename__ = "approval_requests"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), index=True, nullable=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=False)
    requester_user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=True)
    reviewer_user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=True)
    agent_id = Column(Integer, ForeignKey("agents.id"), index=True, nullable=True)
    tool_id = Column(Integer, ForeignKey("tools.id"), index=True, nullable=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), index=True, nullable=True)
    tool_execution_id = Column(Integer, ForeignKey("tool_executions.id"), index=True, nullable=True)
    request_type = Column(String(100), index=True, nullable=False)
    risk_level = Column(String(50), index=True, nullable=False)
    status = Column(String(100), index=True, nullable=False)
    requested_action_summary = Column(Text, nullable=False)
    decision_notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)
    decided_at = Column(DateTime(timezone=True), nullable=True)


class ApprovalEventORM(Base):
    __tablename__ = "approval_events"

    id = Column(Integer, primary_key=True, index=True)
    approval_request_id = Column(
        Integer,
        ForeignKey("approval_requests.id"),
        index=True,
        nullable=False,
    )
    actor_user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=True)
    event_type = Column(String(100), index=True, nullable=False)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class DocumentFolderORM(Base):
    __tablename__ = "document_folders"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), index=True, nullable=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=False)
    name = Column(String(255), index=True, nullable=False)
    description = Column(Text, nullable=True)
    created_by_user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class DocumentORM(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), index=True, nullable=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), index=True, nullable=False)
    folder_id = Column(Integer, ForeignKey("document_folders.id"), index=True, nullable=True)
    created_by_user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=True)
    title = Column(String(255), index=True, nullable=False)
    document_type = Column(String(100), index=True, nullable=False)
    category = Column(String(100), index=True, nullable=False)
    status = Column(String(100), index=True, nullable=False)
    current_version_number = Column(Integer, default=1, nullable=False)
    requires_attorney_review = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class DocumentVersionORM(Base):
    __tablename__ = "document_versions"
    __table_args__ = (
        UniqueConstraint("document_id", "version_number", name="uq_document_version_number"),
    )

    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey("documents.id"), index=True, nullable=False)
    version_number = Column(Integer, nullable=False)
    created_by_user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=True)
    content = Column(Text, nullable=False)
    change_summary = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)


class DocumentReviewORM(Base):
    __tablename__ = "document_reviews"

    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey("documents.id"), index=True, nullable=False)
    document_version_id = Column(Integer, ForeignKey("document_versions.id"), index=True, nullable=True)
    requested_by_user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=True)
    reviewer_user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=True)
    review_type = Column(String(100), index=True, nullable=False)
    status = Column(String(100), index=True, nullable=False)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utc_now, nullable=False)
    decided_at = Column(DateTime(timezone=True), nullable=True)
