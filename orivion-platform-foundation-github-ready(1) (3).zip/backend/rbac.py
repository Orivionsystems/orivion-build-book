from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from .db_models import MembershipORM, WorkspaceORM
from .models import Role, UserInDB


ROLE_LEVELS = {
    Role.viewer.value: 1,
    Role.editor.value: 2,
    Role.admin.value: 3,
    Role.owner.value: 4,
}


def get_membership(
    db: Session,
    user_id: int,
    organization_id: int,
) -> MembershipORM | None:
    return (
        db.query(MembershipORM)
        .filter(
            MembershipORM.user_id == user_id,
            MembershipORM.organization_id == organization_id,
        )
        .first()
    )


def require_org_role(
    db: Session,
    current_user: UserInDB,
    organization_id: int,
    minimum_role: Role,
) -> MembershipORM:
    if current_user.id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Current user is missing database identity",
        )

    membership = get_membership(db, current_user.id, organization_id)
    if membership is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is not a member of this organization",
        )

    user_level = ROLE_LEVELS.get(membership.role, 0)
    required_level = ROLE_LEVELS[minimum_role.value]

    if user_level < required_level:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions",
        )

    return membership


def require_workspace_role(
    db: Session,
    current_user: UserInDB,
    workspace_id: int,
    minimum_role: Role,
) -> WorkspaceORM:
    workspace = db.query(WorkspaceORM).filter(WorkspaceORM.id == workspace_id).first()
    if workspace is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workspace not found",
        )

    require_org_role(
        db=db,
        current_user=current_user,
        organization_id=workspace.organization_id,
        minimum_role=minimum_role,
    )

    return workspace
