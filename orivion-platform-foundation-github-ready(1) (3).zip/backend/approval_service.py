from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from .db_models import ApprovalEventORM, ApprovalRequestORM


def create_approval_event(
    db: Session,
    *,
    approval_request_id: int,
    actor_user_id: int | None,
    event_type: str,
    notes: str | None = None,
) -> ApprovalEventORM:
    event = ApprovalEventORM(
        approval_request_id=approval_request_id,
        actor_user_id=actor_user_id,
        event_type=event_type,
        notes=notes,
    )
    db.add(event)
    db.commit()
    db.refresh(event)
    return event


def create_approval_request(
    db: Session,
    *,
    organization_id: int | None,
    workspace_id: int,
    requester_user_id: int | None,
    agent_id: int | None,
    tool_id: int | None,
    task_id: int | None,
    tool_execution_id: int | None,
    request_type: str,
    risk_level: str,
    requested_action_summary: str,
) -> ApprovalRequestORM:
    approval = ApprovalRequestORM(
        organization_id=organization_id,
        workspace_id=workspace_id,
        requester_user_id=requester_user_id,
        agent_id=agent_id,
        tool_id=tool_id,
        task_id=task_id,
        tool_execution_id=tool_execution_id,
        request_type=request_type,
        risk_level=risk_level,
        status="pending",
        requested_action_summary=requested_action_summary,
    )
    db.add(approval)
    db.commit()
    db.refresh(approval)

    create_approval_event(
        db,
        approval_request_id=approval.id,
        actor_user_id=requester_user_id,
        event_type="created",
        notes="Approval request created",
    )

    return approval


def decide_approval_request(
    db: Session,
    *,
    approval_request_id: int,
    reviewer_user_id: int | None,
    decision: str,
    notes: str | None = None,
) -> ApprovalRequestORM:
    approval = (
        db.query(ApprovalRequestORM)
        .filter(ApprovalRequestORM.id == approval_request_id)
        .first()
    )
    if approval is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Approval request not found")

    if approval.status != "pending":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Approval request is no longer pending")

    if decision not in {"approved", "rejected", "cancelled", "expired"}:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid approval decision")

    approval.status = decision
    approval.reviewer_user_id = reviewer_user_id
    approval.decision_notes = notes
    approval.decided_at = datetime.now(timezone.utc)

    db.add(approval)
    db.commit()
    db.refresh(approval)

    create_approval_event(
        db,
        approval_request_id=approval.id,
        actor_user_id=reviewer_user_id,
        event_type=decision,
        notes=notes,
    )

    return approval
