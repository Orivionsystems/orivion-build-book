# Orivion

Orivion is a starter platform workspace for building the product experience, shared domain code, and supporting documentation in one place.

## What Exists

- `apps/web`: the primary browser application.
- `packages/shared`: shared domain types and utilities.
- `docs`: product and technical notes.
- `work` and `outputs`: Codex working and delivery folders.

## Getting Started

Install dependencies:

```bash
npm install
```

Run the web app:

```bash
npm run dev
```

Build everything:

```bash
npm run build
```

## Workspace Layout

```text
apps/
  web/
    src/
      app/
      components/
      lib/
packages/
  shared/
docs/
```

