from typing import Any, Iterable, List


class BaseAgent:
    """
    Base class for all ORIVION AI agents.

    Every specialized agent should inherit from this class and implement
    process_task().
    """

    def __init__(self, name: str, memory: Any = None) -> None:
        self.name = name
        self.memory = memory

    def setup(self) -> None:
        """Initialize resources or context required by the agent."""

        return None

    def process_task(self, task: Any) -> dict:
        """Process an incoming task and return a result."""

        raise NotImplementedError("Subclasses must implement process_task")

    def run(self, tasks: Iterable[Any]) -> List[dict]:
        """Run the agent over a collection of tasks."""

        return [self.process_task(task) for task in tasks]
