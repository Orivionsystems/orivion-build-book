const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';


export async function getTasks() {
  const response = await fetch(`${API_BASE_URL}/tasks/`);
  if (!response.ok) {
    throw new Error('Failed to load tasks');
  }
  return response.json();
}


export async function createTask(task) {
  const response = await fetch(`${API_BASE_URL}/tasks/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(task),
  });

  if (!response.ok) {
    throw new Error('Failed to create task');
  }

  return response.json();
}


export async function getMemoryItems() {
  const response = await fetch(`${API_BASE_URL}/memory/`);
  if (!response.ok) {
    throw new Error('Failed to load memory');
  }
  return response.json();
}
