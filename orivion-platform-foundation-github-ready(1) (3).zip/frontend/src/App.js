import React, { useEffect, useState } from 'react';

import { createTask, getTasks } from './api';


function App() {
  const [tasks, setTasks] = useState([]);
  const [description, setDescription] = useState('');
  const [agent, setAgent] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    getTasks()
      .then((data) => setTasks(data))
      .catch((err) => setError(err.message));
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');

    const newTask = {
      description,
      assigned_agent: agent || null,
    };

    try {
      const createdTask = await createTask(newTask);
      setTasks([...tasks, createdTask]);
      setDescription('');
      setAgent('');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <main>
      <h1>ORIVION Dashboard</h1>
      <p>Enterprise intelligence system prototype.</p>

      {error && <p role="alert">{error}</p>}

      <section>
        <h2>Create Task</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Task description"
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            required
          />

          <select
            value={agent}
            onChange={(event) => setAgent(event.target.value)}
          >
            <option value="">CEO Agent default</option>
            <option value="CEOAgent">CEO Agent</option>
            <option value="ResearchAgent">Research Agent</option>
          </select>

          <button type="submit">Create Task</button>
        </form>
      </section>

      <section>
        <h2>Tasks</h2>
        <ul>
          {tasks.map((task) => (
            <li key={task.id}>
              {task.description} — Assigned to: {task.assigned_agent || 'CEOAgent'} — Status: {task.status}
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}

export default App;
