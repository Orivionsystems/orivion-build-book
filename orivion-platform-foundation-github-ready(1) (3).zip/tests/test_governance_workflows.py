from uuid import uuid4


def _register_and_login(client):
    username = f"user-{uuid4().hex}"
    password = "test-password-123"
    signup = client.post(
        "/auth/signup",
        json={
            "username": username,
            "email": f"{username}@example.com",
            "password": password,
        },
    )
    assert signup.status_code == 201

    login = client.post(
        "/auth/login",
        data={"username": username, "password": password},
    )
    assert login.status_code == 200
    return {"Authorization": f"Bearer {login.json()['access_token']}"}


def _create_workspace(client, headers):
    organization = client.post(
        "/organizations/",
        json={"name": f"ORIVION Test Org {uuid4().hex}"},
        headers=headers,
    )
    assert organization.status_code == 201
    organization_id = organization.json()["id"]

    workspace = client.post(
        f"/organizations/{organization_id}/workspaces",
        json={"name": "Atlas Governance Lab"},
        headers=headers,
    )
    assert workspace.status_code == 201
    return organization.json(), workspace.json()


def test_workspace_rbac_blocks_non_members(client, auth_headers):
    organization, _workspace = _create_workspace(client, auth_headers)
    outsider_headers = _register_and_login(client)

    response = client.get(
        f"/organizations/{organization['id']}/workspaces",
        headers=outsider_headers,
    )

    assert response.status_code == 403


def test_approval_workflow_records_decision_and_events(client, auth_headers):
    _organization, workspace = _create_workspace(client, auth_headers)

    create_response = client.post(
        "/approvals/",
        json={
            "workspace_id": workspace["id"],
            "request_type": "tool_execution",
            "risk_level": "high",
            "requested_action_summary": "Approve high-risk external research call",
        },
        headers=auth_headers,
    )
    assert create_response.status_code == 200
    approval = create_response.json()
    assert approval["status"] == "pending"

    approve_response = client.post(
        f"/approvals/{approval['id']}/approve",
        json={"notes": "Approved for controlled test execution."},
        headers=auth_headers,
    )
    assert approve_response.status_code == 200
    assert approve_response.json()["status"] == "approved"

    events_response = client.get(
        f"/approvals/{approval['id']}/events",
        headers=auth_headers,
    )
    assert events_response.status_code == 200
    assert [event["event_type"] for event in events_response.json()] == [
        "created",
        "approved",
    ]


def test_high_risk_tool_execution_requires_approval(client, auth_headers):
    _organization, workspace = _create_workspace(client, auth_headers)

    agent_response = client.post(
        "/agents/",
        json={"key": "CEOAgent", "name": "CEO Agent"},
        headers=auth_headers,
    )
    assert agent_response.status_code == 201
    agent = agent_response.json()

    tool_response = client.post(
        "/tools/",
        json={
            "key": "external_api_call",
            "name": "External API Call",
            "tool_type": "external",
            "risk_level": "high",
            "requires_human_approval": True,
        },
        headers=auth_headers,
    )
    assert tool_response.status_code == 201
    tool = tool_response.json()

    permission_response = client.post(
        "/tools/permissions",
        json={
            "agent_id": agent["id"],
            "tool_id": tool["id"],
            "workspace_id": workspace["id"],
            "can_execute": True,
        },
        headers=auth_headers,
    )
    assert permission_response.status_code == 201

    execution_response = client.post(
        "/tools/execute",
        json={
            "agent_id": agent["id"],
            "tool_id": tool["id"],
            "workspace_id": workspace["id"],
            "input_summary": "Call a controlled external API placeholder.",
        },
        headers=auth_headers,
    )
    assert execution_response.status_code == 201
    execution = execution_response.json()
    assert execution["status"] == "pending_approval"
    assert execution["approval_status"] == "required"


def test_document_vault_versions_reviews_and_audit_logs(client, auth_headers):
    organization, workspace = _create_workspace(client, auth_headers)

    folder_response = client.post(
        "/documents/folders",
        json={
            "organization_id": organization["id"],
            "workspace_id": workspace["id"],
            "name": "Founder Legal Stack",
        },
        headers=auth_headers,
    )
    assert folder_response.status_code == 201
    folder = folder_response.json()

    document_response = client.post(
        "/documents/",
        json={
            "organization_id": organization["id"],
            "workspace_id": workspace["id"],
            "folder_id": folder["id"],
            "title": "Founder IP Assignment",
            "document_type": "agreement",
            "category": "legal",
            "content": "Initial founder IP assignment draft.",
            "requires_attorney_review": True,
        },
        headers=auth_headers,
    )
    assert document_response.status_code == 201
    document = document_response.json()
    assert document["current_version_number"] == 1

    version_response = client.post(
        f"/documents/{document['id']}/versions",
        json={
            "content": "Updated founder IP assignment draft.",
            "change_summary": "Added attorney review language.",
        },
        headers=auth_headers,
    )
    assert version_response.status_code == 201
    assert version_response.json()["version_number"] == 2

    review_response = client.post(
        "/documents/reviews",
        json={
            "document_id": document["id"],
            "review_type": "attorney_review",
            "notes": "Needs attorney review before use.",
        },
        headers=auth_headers,
    )
    assert review_response.status_code == 201
    assert review_response.json()["status"] == "requested"

    reviews_list = client.get(
        "/documents/reviews/list",
        params={"workspace_id": workspace["id"]},
        headers=auth_headers,
    )
    assert reviews_list.status_code == 200
    assert len(reviews_list.json()) == 1

    audit_response = client.get(
        "/audit-logs/",
        params={"workspace_id": workspace["id"]},
        headers=auth_headers,
    )
    assert audit_response.status_code == 200
    entity_types = {entry["entity_type"] for entry in audit_response.json()}
    assert {"document", "document_version", "document_review"}.issubset(entity_types)
