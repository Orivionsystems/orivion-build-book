from backend.main import app


def test_governance_and_document_routes_are_registered():
    paths = set(app.openapi()["paths"])

    assert "/agents/" in paths
    assert "/tools/execute" in paths
    assert "/approvals/" in paths
    assert "/documents/" in paths
