def test_create_task_defaults_to_ceo_agent(client, auth_headers):
    response = client.post(
        "/tasks/",
        json={"description": "Prepare executive briefing"},
        headers=auth_headers,
    )
    assert response.status_code == 201
    data = response.json()
    assert data["description"] == "Prepare executive briefing"
    assert data["status"] == "processed_by_ceo_agent"


def test_create_task_with_research_agent(client, auth_headers):
    response = client.post(
        "/tasks/",
        json={
            "description": "Research open-source agent frameworks",
            "assigned_agent": "ResearchAgent",
        },
        headers=auth_headers,
    )
    assert response.status_code == 201
    data = response.json()
    assert data["assigned_agent"] == "ResearchAgent"
    assert data["status"] == "processed_by_research_agent"
