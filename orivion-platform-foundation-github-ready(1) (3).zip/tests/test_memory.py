def test_create_and_search_memory(client, auth_headers):
    create_response = client.post(
        "/memory/",
        json={"content": "ORIVION uses agents, memory, and workflow orchestration."},
        headers=auth_headers,
    )
    assert create_response.status_code == 201

    search_response = client.get(
        "/memory/search/",
        params={"query": "agents"},
        headers=auth_headers,
    )
    assert search_response.status_code == 200
    results = search_response.json()
    assert len(results) >= 1
    assert "agents" in results[0]["content"].lower()
